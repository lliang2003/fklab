// **********************************************************************
//
// Copyright (c) 2003-2006 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

#ifndef ICE_GRID_TRACE_LEVELS_H
#define ICE_GRID_TRACE_LEVELS_H

#include <IceUtil/Shared.h>
#include <Ice/PropertiesF.h>
#include <Ice/LoggerF.h>

namespace IceGrid
{

class TraceLevels : public ::IceUtil::Shared
{
public:

    TraceLevels(const ::Ice::PropertiesPtr&, const Ice::LoggerPtr&, bool);
    virtual ~TraceLevels();

    const int application;
    const char* applicationCat;

    const int node;
    const char* nodeCat;

    const int server;
    const char* serverCat;

    const int adapter;
    const char* adapterCat;

    const int object;
    const char* objectCat;

    const int activator;
    const char* activatorCat;

    const int patch;
    const char* patchCat;

    const int locator;
    const char* locatorCat;

    const int session;
    const char* sessionCat;

    const Ice::LoggerPtr logger;
};

typedef IceUtil::Handle<TraceLevels> TraceLevelsPtr;

} // End namespace IceGrid

#endif
